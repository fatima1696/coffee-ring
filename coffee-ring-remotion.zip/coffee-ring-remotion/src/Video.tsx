import React from 'react';
import {AbsoluteFill, Series} from 'remotion';
import {BEATS, FPS} from './timeline';
import {Captions} from './Captions';
import {Scene1Ring} from './scenes/Scene1Ring';
import {Scene2FreshDrop} from './scenes/Scene2FreshDrop';
import {Scene3Drying} from './scenes/Scene3Drying';
import {Scene4Pinned} from './scenes/Scene4Pinned';
import {Scene5Flow} from './scenes/Scene5Flow';
import {Scene6Pile} from './scenes/Scene6Pile';
import {Scene7EggJam} from './scenes/Scene7EggJam';
import {Scene8TwoStains} from './scenes/Scene8TwoStains';
import {Scene9Cafe} from './scenes/Scene9Cafe';

export const SCENES = [
  Scene1Ring,
  Scene2FreshDrop,
  Scene3Drying,
  Scene4Pinned,
  Scene5Flow,
  Scene6Pile,
  Scene7EggJam,
  Scene8TwoStains,
  Scene9Cafe,
];

export const CoffeeRing: React.FC = () => (
  <AbsoluteFill>
    <Series>
      {BEATS.map((b, i) => {
        const Scene = SCENES[i];
        return (
          <Series.Sequence key={b.id} name={b.id} durationInFrames={b.sec * FPS}>
            <Scene />
          </Series.Sequence>
        );
      })}
    </Series>
    <Captions />
  </AbsoluteFill>
);
